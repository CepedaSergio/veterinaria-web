<?php
require_once 'model/database.php';

$controller = 'alumno';
$controller2 = 'profesor';
$controller3 ='cursos';

// Todo esta lógica hara el papel de un FrontController
if(!isset($_REQUEST['c']))
{
    require_once "controller/$controller.controller.php";
    $controller = ucwords($controller) . 'Controller';
    $controller = new $controller;
    $controller->Index();    
}
else
{
    // Obtenemos el controlador que queremos cargar
    $controller = strtolower($_REQUEST['c']);
    $accion = isset($_REQUEST['a']) ? $_REQUEST['a'] : 'Index';
    
    // Instanciamos el controlador
    require_once "controller/$controller.controller.php";
    $controller = ucwords($controller) . 'Controller';
    $controller = new $controller;
    
    // Llama la accion
    call_user_func( array( $controller, $accion ) );
}

if(!isset($_REQUEST['c']))
{
    require_once "controller/$controller2.controller.php";
    $controller2 = ucwords($controller2) . 'Controller';
    $controller2 = new $controller2;
    $controller2->Index();    
}
else
{
    // Obtenemos el controlador que queremos cargar
    $controller2 = strtolower($_REQUEST['c']);
    $accion2 = isset($_REQUEST['a']) ? $_REQUEST['a'] : 'Index';
    
    // Instanciamos el controlador
    require_once "controller/$controller2.controller.php";
    $controller2 = ucwords($controller2) . 'Controller';
    $controller2 = new $controller2;
    
    // Llama la accion
    call_user_func( array( $controller2, $accion2 ) );
}
if(!isset($_REQUEST['c']))
{
    require_once "controller/$controller3.controller.php";
    $controller3 = ucwords($controller3) . 'Controller';
    $controller3 = new $controller3;
    $controller3->Index();    
}
else
{
    // Obtenemos el controlador que queremos cargar
    $controller3 = strtolower($_REQUEST['c']);
    $accion2 = isset($_REQUEST['a']) ? $_REQUEST['a'] : 'Index';
    
    // Instanciamos el controlador
    require_once "controller/$controller3.controller.php";
    $controller3 = ucwords($controller3) . 'Controller';
    $controller3 = new $controller3;
    
    // Llama la accion
    call_user_func( array( $controller3, $accion3 ) );
}